<p>Este es un correo de prueba</p>
<p>Nombres y Apellidos del responsable: <?php echo $fullname;?> </p>
<p>Plan: <?php echo $plan;?> </p>
<p>Estado: <?php echo $estado;?> </p>
<p>Fecha de Inicio: <?php echo $inicio;?> </p>
<p>Fecha de Fin: <?php echo $fin;?> </p>
<p>Alerta: <?php echo $alerta;?> </p>