<p>Nombres y Apellidos: <?php echo $fullname;?> </p>
<p>Plan: <?php echo $plan;?> </p>
<p>Actividad: <?php echo $actividad;?> </p>
<p>Estado: <?php echo $estado;?> </p>
<p>Fecha Inicio: <?php echo $inicio;?> </p>
<p>Fecha Fin: <?php echo $fin;?> </p>

<p>Alerta: <?php echo $alerta;?> </p>